# Technova
This project's aim is to make a website to the business named Solekta.
