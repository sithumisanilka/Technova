package com.solekta.solekta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechnovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
